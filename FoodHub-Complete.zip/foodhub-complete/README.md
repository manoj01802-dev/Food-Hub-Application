# FoodHub Complete Project

This folder contains the complete FoodHub development project:

- `backend` — Java 17 Spring Boot API for STS/Eclipse
- `frontend` — React + Node.js website
- `database/foodhub_db.sql` — MySQL schema
- `docker-compose.yml` — one-command MySQL database startup

## What you need to install

Install the following once on your computer:

1. Java JDK 17
2. Spring Tool Suite 4 (STS)
3. Node.js 20.19 or newer
4. Docker Desktop (recommended for the database)

## Start everything

### 1. Start the database

Open a terminal in this `foodhub-complete` folder and run:

```bash
docker compose up -d database
```

This starts MySQL at `localhost:3306` with these development credentials:

```text
Database: foodhub_db
Username: root
Password: foodhub
```

The included SQL schema is applied automatically the first time the database starts.

If you already have MySQL installed and prefer to use it, run `database/foodhub_db.sql` in MySQL Workbench. Then edit `backend/src/main/resources/application.properties` to use your MySQL username and password.

### 2. Start the backend in STS

1. Open STS.
2. Select **File → Import… → Maven → Existing Maven Projects**.
3. Select the `backend` folder and click **Finish**.
4. Open `src/main/java/com/foodhub/FoodhubApplication.java`.
5. Right-click it → **Run As → Spring Boot App**.

Wait for the console to say that the application has started on port `8080`.

### 3. Start the frontend

Open another terminal in the `frontend` folder and run:

```bash
npm install
npm run dev
```

Open the address shown in the terminal, normally `http://localhost:5173`.

## First test

1. In the website, select **Create one**.
2. Enter a name, email, and password of at least six characters.
3. Select **Create account**.
4. The website automatically logs you in and displays your profile.

## Stop the database

From the `foodhub-complete` folder:

```bash
docker compose down
```

Your database data is retained. To remove its data too, run `docker compose down -v`.

## Development-only settings

The supplied MySQL password and JWT secret are for local development. Change them before deploying the project anywhere public.
