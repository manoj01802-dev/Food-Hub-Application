import { useEffect, useState } from 'react';
import { api } from './api';

const emptyRegister = { name: '', email: '', password: '' };
const emptyLogin = { email: '', password: '' };

export default function App() {
  const [page, setPage] = useState('login');
  const [form, setForm] = useState(emptyLogin);
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('foodhub_token');
    if (token) loadProfile(token);
  }, []);

  async function loadProfile(token) {
    try {
      setLoading(true); setError('');
      const profile = await api.me(token);
      setUser(profile); setPage('profile');
    } catch (err) {
      localStorage.removeItem('foodhub_token');
      setError('Your saved session has expired. Please log in again.');
      setPage('login');
    } finally { setLoading(false); }
  }

  function switchPage(nextPage) {
    setPage(nextPage); setForm(nextPage === 'register' ? emptyRegister : emptyLogin);
    setError(''); setMessage('');
  }

  function update(event) { setForm({ ...form, [event.target.name]: event.target.value }); }

  async function submit(event) {
    event.preventDefault(); setError(''); setMessage(''); setLoading(true);
    try {
      const result = page === 'register' ? await api.register(form) : await api.login(form);
      localStorage.setItem('foodhub_token', result.token);
      setMessage(page === 'register' ? 'Account created successfully.' : 'Welcome back!');
      await loadProfile(result.token);
    } catch (err) { setError(err.message); } finally { setLoading(false); }
  }

  function logout() {
    localStorage.removeItem('foodhub_token'); setUser(null); setMessage('You have been logged out.'); setPage('login');
  }

  return <main className="app-shell">
    <header><a className="brand" onClick={() => user ? setPage('profile') : switchPage('login')}>Food<span>Hub</span></a>{user && <button className="link-button" onClick={logout}>Log out</button>}</header>
    <section className="hero"><p className="eyebrow">FOOD DELIVERY MADE SIMPLE</p><h1>Good food,<br/><em>delivered simply.</em></h1><p className="subtitle">Create an account or sign in to FoodHub.</p></section>
    <section className="card">
      {page === 'profile' && user ? <Profile user={user} onLogout={logout} /> : <AuthForm page={page} form={form} update={update} submit={submit} switchPage={switchPage} loading={loading} />}
      {error && <p className="notice error">{error}</p>}
      {message && <p className="notice success">{message}</p>}
    </section>
  </main>;
}

function AuthForm({ page, form, update, submit, switchPage, loading }) {
  const registering = page === 'register';
  return <><div className="card-heading"><h2>{registering ? 'Create your account' : 'Welcome back'}</h2><p>{registering ? 'Join FoodHub in a few seconds.' : 'Log in to see your FoodHub profile.'}</p></div>
    <form onSubmit={submit}>
      {registering && <Field label="Full name" name="name" value={form.name} onChange={update} placeholder="Your name" />}
      <Field label="Email address" type="email" name="email" value={form.email} onChange={update} placeholder="you@example.com" />
      <Field label="Password" type="password" name="password" value={form.password} onChange={update} placeholder="At least 6 characters" />
      <button className="primary" disabled={loading}>{loading ? 'Please wait…' : registering ? 'Create account' : 'Log in'}</button>
    </form>
    <p className="switcher">{registering ? 'Already have an account?' : 'New to FoodHub?'} <button onClick={() => switchPage(registering ? 'login' : 'register')}>{registering ? 'Log in' : 'Create one'}</button></p>
  </>;
}

function Field({ label, type = 'text', ...props }) { return <label>{label}<input type={type} required {...props} /></label>; }

function Profile({ user, onLogout }) { return <div className="profile"><div className="avatar">{user.name.charAt(0).toUpperCase()}</div><p className="eyebrow">YOUR PROFILE</p><h2>Hello, {user.name}!</h2><p className="profile-text">You are signed in to FoodHub.</p><dl><div><dt>Email</dt><dd>{user.email}</dd></div><div><dt>Role</dt><dd><span className="badge">{user.role.replace('_', ' ')}</span></dd></div></dl><button className="primary" onClick={onLogout}>Log out</button></div>; }
