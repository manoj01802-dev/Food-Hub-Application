# FoodHub Frontend

This is a React frontend for the FoodHub Spring Boot API. It supports registration, login, saving a JWT session, viewing the signed-in profile, and logging out.

## Before starting

1. Start the FoodHub Spring Boot backend first on `http://localhost:8080`.
2. Install Node.js 20.19 or newer from https://nodejs.org if it is not already installed.

## Run the frontend

1. Open a terminal in the extracted `foodhub-frontend` folder.
2. Run:

   ```bash
   npm install
   npm run dev
   ```

3. Open the address shown in the terminal, normally `http://localhost:5173`.

## Use it

1. Select **Create one**.
2. Enter your name, email, and a password with at least six characters.
3. Select **Create account**.
4. You will be signed in automatically and shown your profile.

The token is saved in the browser only for this local development project. Use the **Log out** button to remove it.

## Important

The updated backend includes CORS support for `http://localhost:5173`. Use the updated backend ZIP supplied alongside this frontend ZIP.
