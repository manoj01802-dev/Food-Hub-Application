package com.foodhub.dto;

import jakarta.validation.constraints.*;

public record RegisterRequest(
        @NotBlank(message = "Name is required") @Size(max = 100) String name,
        @NotBlank @Email(message = "A valid email is required") @Size(max = 150) String email,
        @NotBlank @Size(min = 6, max = 100, message = "Password must be 6-100 characters") String password) { }
