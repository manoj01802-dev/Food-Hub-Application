package com.foodhub.controller;

import com.foodhub.dto.UserResponse;
import com.foodhub.entity.User;
import com.foodhub.exception.ResourceNotFoundException;
import com.foodhub.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/users")
public class UserController {
    private final UserRepository users; public UserController(UserRepository users) { this.users = users; }
    @GetMapping("/me") public UserResponse me(Authentication authentication) {
        User user = users.findByEmail(authentication.getName()).orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return UserResponse.from(user);
    }
}
