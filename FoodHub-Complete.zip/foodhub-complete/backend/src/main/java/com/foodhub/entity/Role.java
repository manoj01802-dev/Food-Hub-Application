package com.foodhub.entity;

public enum Role { CUSTOMER, RESTAURANT_OWNER, ADMIN }
