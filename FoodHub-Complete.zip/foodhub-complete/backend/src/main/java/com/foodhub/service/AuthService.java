package com.foodhub.service;

import com.foodhub.dto.*;
import com.foodhub.entity.*;
import com.foodhub.exception.BadRequestException;
import com.foodhub.repository.UserRepository;
import com.foodhub.security.JwtService;
import org.springframework.security.authentication.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    private final UserRepository users; private final PasswordEncoder encoder; private final AuthenticationManager authenticationManager; private final JwtService jwt;
    public AuthService(UserRepository users, PasswordEncoder encoder, AuthenticationManager authenticationManager, JwtService jwt) { this.users = users; this.encoder = encoder; this.authenticationManager = authenticationManager; this.jwt = jwt; }
    public AuthResponse register(RegisterRequest request) {
        String email = request.email().trim().toLowerCase();
        if (users.existsByEmail(email)) throw new BadRequestException("Email is already registered");
        User user = new User(); user.setName(request.name().trim()); user.setEmail(email); user.setPassword(encoder.encode(request.password())); user.setRole(Role.CUSTOMER);
        return response(users.save(user));
    }
    public AuthResponse login(LoginRequest request) {
        try { authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.email().trim().toLowerCase(), request.password())); }
        catch (AuthenticationException ex) { throw new BadRequestException("Invalid email or password"); }
        User user = users.findByEmail(request.email().trim().toLowerCase()).orElseThrow(); return response(user);
    }
    private AuthResponse response(User user) { return new AuthResponse(jwt.generateToken(user), "Bearer", user.getId(), user.getName(), user.getEmail(), user.getRole().name()); }
}
