# FoodHub Backend

A Java 17 / Spring Boot REST backend that includes MySQL persistence, Spring Security, JWT authentication, validation, and role-based authorization scaffolding.

## Requirements

- Java 17 (JDK, not only a JRE)
- MySQL Server 8.x running locally
- Spring Tool Suite 4 (or Eclipse with Spring Tools)

## Configure MySQL

1. Start MySQL.
2. In MySQL Workbench or the MySQL command line, create the database (optional: the application can create it):

   ```sql
   CREATE DATABASE foodhub_db;
   ```

3. Open `src/main/resources/application.properties`.
4. Replace `YOUR_MYSQL_PASSWORD` with the password for the configured MySQL user. Change the username too if you do not use `root`.

## Import and run in STS

1. Extract `foodhub.zip` anywhere convenient.
2. Open STS.
3. Select **File → Import… → Maven → Existing Maven Projects**.
4. Select the extracted `foodhub` folder as the root directory, then click **Finish**.
5. Wait for Maven dependencies to download. If there is a Java version warning, set the project JRE to a Java 17 JDK: right-click project → **Properties → Java Build Path → Libraries**.
6. In Package Explorer, open `src/main/java` → `com.foodhub` → `FoodhubApplication.java`.
7. Right-click it → **Run As → Spring Boot App**.
8. The API starts on `http://localhost:8080`.

## Endpoints and Postman requests

You can also import `FoodHub.postman_collection.json` into Postman. After registering or logging in, copy the returned token into the collection's `token` variable before sending **My Profile**.

### Register (public)

`POST http://localhost:8080/api/auth/register`

```json
{
  "name": "Shrath",
  "email": "shrath@example.com",
  "password": "password123"
}
```

The response is `201 Created` and contains a `token` value.

### Login (public)

`POST http://localhost:8080/api/auth/login`

```json
{
  "email": "shrath@example.com",
  "password": "password123"
}
```

### Current user (JWT-protected)

`GET http://localhost:8080/api/users/me`

In Postman, select **Authorization** → **Bearer Token**, then paste only the returned `token` value (the long text beginning with `eyJ`). Do **not** type `Bearer` into the token field; Postman adds it automatically.

Alternatively add this header manually:

```text
Authorization: Bearer <token>
```

Expected response:

```json
{
  "id": 1,
  "name": "Shrath",
  "email": "shrath@example.com",
  "role": "CUSTOMER"
}
```

## Roles

New registrations receive `CUSTOMER`. The `Role` enum also has `RESTAURANT_OWNER` and `ADMIN` for future features. Security is already mapped as follows:

- `/api/users/**` — any authenticated user
- `/api/restaurant/**` — `RESTAURANT_OWNER` or `ADMIN`
- `/api/admin/**` — `ADMIN` only

For a development-only test, change a user's `role` column in MySQL to `ADMIN` or `RESTAURANT_OWNER`, log in again to obtain a new token, and add a controller endpoint under the matching path.

## Important notes

- Passwords are stored using BCrypt, never as plain text.
- JWTs expire after 24 hours by default. Edit `app.jwt.expiration-ms` if needed.
- Replace `app.jwt.secret` with a secure Base64-encoded key before deployment.
- This project uses `spring.jpa.hibernate.ddl-auto=update` for development. Use database migrations in production.
